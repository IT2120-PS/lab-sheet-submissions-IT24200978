setwd("C:\\Users\\HP\\Desktop\\IT24200978 - Lab 09")  

set.seed(123)   
bake_time <- rnorm(25, mean = 45, sd = 2)
bake_time

t.test(bake_time, mu = 46, alternative = "less")

mean(bake_time)
sd(bake_time)
